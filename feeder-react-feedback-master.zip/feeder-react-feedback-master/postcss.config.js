module.exports = {
  plugins: [require("autoprefixer")],
};

// TODO uninstall postcss-prefixer
